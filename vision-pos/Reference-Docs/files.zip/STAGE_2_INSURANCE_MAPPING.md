## Stage 2: Insurance Mapping âœ… COMPLETE

**Status**: TypeScript mapping file implemented (2026-01-15)
**Architecture**: Single source of truth in `src/lib/data/insurance-tier-mappings.ts`

### Functionality Goal
Map products to insurance tier codes, and tier codes to copay field names in authorization JSON. **No database lookups during pricing** - all mappings are compile-time constants.

---

### Architecture: TypeScript Mapping File

```
PRICE GENERATION FLOW:
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”      â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”      â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ INSURANCE-TIER-     â”‚      â”‚  PATIENT AUTH       â”‚      â”‚ PATIENT_PRICE_LIST  â”‚
â”‚ MAPPINGS.TS (FILE)  â”‚  +   â”‚  (unified table)    â”‚  =   â”‚ (personalized)      â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤      â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤      â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ PRODUCT_TIERS:      â”‚      â”‚ copays JSON:        â”‚      â”‚ John Smith          â”‚
â”‚  "Varilux X":       â”‚      â”‚ {                   â”‚      â”‚ â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ â”‚
â”‚    eyemed: "tier_3" â”‚      â”‚   progressiveTier3: â”‚      â”‚ Varilux X: $110     â”‚
â”‚                     â”‚      â”‚     110,            â”‚      â”‚ Crizal Rock: $68    â”‚
â”‚ EYEMED_TIER_TO_     â”‚      â”‚   arTier2: 68,      â”‚      â”‚ Polycarbonate: $40  â”‚
â”‚ COPAY:              â”‚      â”‚   polycarbonate: 40,â”‚      â”‚ Trivex: $68 (80%)   â”‚
â”‚  "tier_3" â†’         â”‚      â”‚   allOtherLens      â”‚      â”‚                     â”‚
â”‚    "progressiveTier3â”‚      â”‚     Options:        â”‚      â”‚                     â”‚
â”‚                     â”‚      â”‚     "DISCOUNT_20"   â”‚      â”‚                     â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜      â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜      â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
        â”‚                              â”‚                           â”‚
        â”‚  PRECOMPUTE SERVICE          â”‚                           â”‚
        â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â–ºâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜                           â”‚
                              â”‚                                    â”‚
                              â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â–º GENERATES â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Key Principle**: Tier mappings in TypeScript file + copays in authorization JSON â†’ patient price list. No database queries for tier lookups.

---

### File Structure

**Location**: `src/lib/data/insurance-tier-mappings.ts`

```typescript
// 1. PRODUCT_TIERS - Maps products to tier codes per carrier
export const PRODUCT_TIERS: Record<string, ProductTierMap> = {
  "Varilux Comfort DRx": {
    vsp: "JA",        // VSP tier code
    eyemed: "tier_3", // EyeMed tier code
    spectera: "III"   // Spectera tier code
  },
  "Polycarbonate": {
    vsp: "AD",
    eyemed: "polycarbonate",
    spectera: "polycarbonate"
  },
  // null = not covered (cash only)
  "Neurolens SV": { vsp: null, eyemed: null, spectera: null },
  // ... 40+ products
};

// 2. TIER_TO_COPAY - Maps tier codes to copay field names
export const EYEMED_TIER_TO_COPAY: CopayFieldMap = {
  "tier_3": "progressiveTier3",     // Look up copays.progressiveTier3
  "ar_tier_3": "DISCOUNT_20_PERCENT", // Special: 20% off retail
  "polycarbonate": "polycarbonate", // Look up copays.polycarbonate
  // ...
};

export const VSP_TIER_TO_COPAY: CopayFieldMap = { /* ... */ };
export const SPECTERA_TIER_TO_COPAY: CopayFieldMap = { /* ... */ };
```

---

### Pricing Methods Explained

| Method | Meaning | When Used |
|--------|---------|-----------|
| `by_tier` | Patient pays copay from authorization JSON | Product has explicit copay value |
| `ins_discount` | Patient pays (100 - X)% of retail | Authorization has "DISCOUNT_XX" string |
| `cash_only` | Patient pays full retail | Product tier is null (not covered) |
| `uc_discount` | 80% fallback (DATA QUALITY ISSUE) | Should be rare - indicates missing data |

**IMPORTANT**: `uc_discount` indicates extraction or mapping issues. A well-functioning system should have ZERO `uc_discount` products.

---

### Special Values in Authorization copays JSON

The GPT extraction stores copays as numbers OR discount strings:

```json
{
  "examCopay": 10,
  "progressiveTier3": 110,
  "arTier3": "DISCOUNT_20",    // String! Patient pays 80% retail
  "allOtherLensOptions": "DISCOUNT_20"  // EyeMed catch-all
}
```

The precompute service handles both:
- Number â†’ use directly as copay
- "DISCOUNT_XX" â†’ calculate (100 - XX)% of retail price

---

### Product Categories (41 products mapped)

**Single Vision**: 5 products (3 covered, 2 cash-only)
**Bifocals**: 2 products (covered)
**Progressives**: 6 products (3 covered, 3 cash-only)
**Materials**: 5 products (4 covered, 1 cash-only)
**AR Coatings**: 7 products (5 covered, 2 cash-only)
**Photochromic**: 2 products (covered)
**Addons**: 11 products (8 covered, 3 cash-only)
**Mount Fees**: 3 products (covered)

---

### Consumer: Price List Precompute Service

**Location**: `src/lib/services/price-list-precompute.ts`

The precompute service:
1. Gets product's tier code from `PRODUCT_TIERS`
2. Maps tier code to copay field via `EYEMED_TIER_TO_COPAY` (etc)
3. Looks up value in authorization's `copays` JSON
4. Handles DISCOUNT_XX strings and allOtherLensOptions fallback
5. Saves to `patient_price_lists` table

```typescript
// Simplified flow
const tierCode = PRODUCT_TIERS[product.name]?.eyemed; // "tier_3"
const copayField = EYEMED_TIER_TO_COPAY[tierCode];    // "progressiveTier3"
const copayValue = auth.copays[copayField];           // 110 or "DISCOUNT_20"

if (typeof copayValue === 'number') {
  finalPrice = copayValue;
  pricingMethod = 'by_tier';
} else if (copayValue?.startsWith('DISCOUNT_')) {
  const percent = parseInt(copayValue.replace('DISCOUNT_', ''));
  finalPrice = retailPrice * (100 - percent) / 100;
  pricingMethod = 'ins_discount';
}
```

---

### Decision Point: STAGE 2 COMPLETE âœ…

**Test 1**: TypeScript mapping file compiles without errors
```bash
npx tsc --noEmit src/lib/data/insurance-tier-mappings.ts
```
**Result**: No errors

**Test 2**: All everyday products have tier mappings
```typescript
const products = Object.keys(PRODUCT_TIERS);
console.log(`${products.length} products mapped`); // 41 products
```
**Result**: 41 products mapped

**Test 3**: Tier-to-copay mappings exist for all 3 carriers
```typescript
Object.keys(EYEMED_TIER_TO_COPAY).length  // 20+ mappings
Object.keys(VSP_TIER_TO_COPAY).length     // 20+ mappings
Object.keys(SPECTERA_TIER_TO_COPAY).length // 15+ mappings
```
**Result**: All carriers have complete mappings

**Action**: âœ… COMPLETE â†’ Proceed to Stage 3

---

