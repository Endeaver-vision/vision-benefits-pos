## Stage 3: Insurance Scanner + Price List Generation âœ… EYEMED COMPLETE

**Status**: EyeMed fully working (2026-01-15), VSP/Spectera not yet tested
**Test Patients**: 5 EyeMed patients available for UI verification (see below)

### Functionality Goal
Extract benefit data from insurance documents AND generate complete patient price list with validation.

### Implementation Status:

**Backend Pipeline** âœ… COMPLETE
- Document upload â†’ `/api/documents/upload` route
- OCR processing â†’ GPT-4o Vision (single call for OCR + extraction)
- GPT-4o extraction â†’ `src/lib/services/ocr/gpt-extraction.ts`
- Authorization creation â†’ unified `insurance_authorizations` table (JSON copays)
- Price precomputation â†’ `src/lib/services/price-list-precompute.ts`
- Patient price list storage â†’ `patient_price_lists` table

**EyeMed Extraction** âœ… VERIFIED WORKING (2026-01-15)
- Copays extracted correctly (including `allOtherLensOptions: "DISCOUNT_20"`)
- Authorization copays JSON populated with all values
- Price precomputation uses `ins_discount` method (NOT `uc_discount` fallback)
- ZERO products falling back to 80% U&C discount

**Key Fix (2026-01-15)**: Updated `/api/documents/[id]/verify/route.ts` to:
- Handle DISCOUNT_XX strings (e.g., "DISCOUNT_20", "DISCOUNT_30")
- Extract `allOtherLensOptions` field from GPT extraction
- Store both numbers AND discount strings in copays JSON

**Scanner UI** âœ… COMPLETE
- Customer selection flow â†’ `/scanner` page
- Multi-document upload
- Real-time processing status
- Extracted benefits display
- Auto-verification trigger

**Admin Review Queue** âœ… COMPLETE
- Pending documents queue â†’ `/admin/scanner` page
- Extraction validation checkpoints (4 checks)
- Price list generation summary
- Verify & Generate Prices action

**Files Updated (2026-01-15):**
- `src/app/api/documents/[id]/verify/route.ts` - Fixed DISCOUNT_XX handling, added allOtherLensOptions
- `src/lib/services/price-list-precompute.ts` - Uses TypeScript mappings, handles ins_discount

---

### Test Patients for UI Verification (EyeMed)

| Customer | Document | Customer ID |
|----------|----------|-------------|
| Marcell Bailey Ebdrup | SS_eyemed.pdf | cust_93800643 |
| Jacquelyn Burke | AP_eyemed.pdf | cust_134599062 |
| Christopher Irvine | GB_eyemed.pdf | cust_123160600 |
| Priscila Pinto | eyemed2025-cs.pdf | cust_132371817 |
| Juan Abadia | ER-eyemed.pdf | cust_99896041 |
| Daniel Dasilveira | DD-INS.pdf | cminudpyls7ymp5h5ta |

**How to verify in UI:**
1. Go to `/customers/[customerId]?tab=price-plan`
2. Check "Insurance & Pricing" tab
3. Verify products show:
   - `by_tier` for products with explicit copays
   - `ins_discount` for products using allOtherLensOptions
   - `cash_only` for uncovered products
   - **NO** `uc_discount` (if you see this, there's a bug)

---

### Process Flow:
1. **Upload** â†’ Insurance document (PDF/image)
2. **Extract** â†’ GPT-4o extracts benefit data (including DISCOUNT_XX strings)
3. **Store** â†’ Save to unified `insurance_authorizations` table (JSON copays)
4. **Generate** â†’ Build patient price list using TypeScript tier mappings
5. **Validate** â†’ Automated checks (pricing method distribution)
6. **Review** â†’ Human visual inspection in customer profile

### Extraction Data Points:
- Member ID, Group Number, Plan Name
- Exam Copay, Materials Copay, Frame Allowance
- Progressive lens copays (Standard, Tier 1-5)
- Material copays (Polycarbonate adult/child, Trivex, High Index)
- Enhancement copays (Photochromic, Polarized, AR Coatings, Tint, Blue Light Filter)
- **allOtherLensOptions** - EyeMed catch-all (typically "DISCOUNT_20")

### Automated Redundancy Checkpoints:

**Checkpoint 1: Copays JSON Populated**
```sql
-- Verify authorization has copays JSON with values
SELECT
  id,
  carrier,
  copays->>'progressiveTier3' as prog_tier3,
  copays->>'allOtherLensOptions' as all_other
FROM insurance_authorizations
WHERE customer_id = '[customer_id]' AND is_active = true;
```
**Result**: copays JSON has expected fields (numbers or "DISCOUNT_XX" strings)

**Checkpoint 2: Price List Generated**
```sql
-- Verify price list has entries
SELECT COUNT(*) as total_products
FROM patient_price_lists
WHERE customer_id = '[customer_id]' AND active = true;
```
**Result**: total_products > 0 (should be ~41 for lens products)

**Checkpoint 3: Pricing Method Distribution (THE KEY TEST)**
```sql
-- Verify NO products using uc_discount (bad fallback)
SELECT
  pricing_method,
  COUNT(*) as count
FROM patient_price_lists
WHERE customer_id = '[customer_id]' AND active = true
GROUP BY pricing_method
ORDER BY count DESC;
```
**Expected Result**:
| pricing_method | count | meaning |
|---------------|-------|---------|
| `by_tier` | 17 | Products with explicit copay |
| `ins_discount` | 13 | Products using DISCOUNT_XX |
| `cash_only` | 11 | Products not covered |
| `uc_discount` | **0** | âš ï¸ If > 0, there's a bug! |

**CRITICAL**: `uc_discount` count MUST be 0. If you see `uc_discount` products, the extraction or mapping is broken.

### Human Visual Inspection UI:

**Section 1: Extracted Benefits**
```
âœ“ Exam Copay: $10
âœ“ Frame Allowance: $150
âœ“ Progressive Tier 1: $105
âœ“ Progressive Tier 2: $115
âš  Progressive Tier 3: NOT FOUND (will use 80% retail)
âœ“ Polycarbonate: $40
âœ“ Photochromic: $75
```

**Section 2: Price List Summary**
```
Generated 250 product prices:
âœ“ 185 products: Tier-based pricing (74%)
âš  65 products: 80% retail fallback (26%)

Common Products Preview:
âœ“ Varilux X-Series â†’ $115 (Tier 2)
âœ“ Crizal Sapphire â†’ $85 (Premium AR)
âš  Zeiss DriveSafe â†’ $96 (80% retail - no tier mapping)
```

**Section 3: Action Buttons**
- [Approve & Save] - Proceed to patient profile
- [Edit Copays] - Manually adjust extracted values
- [Rescan Document] - Start over
- [Flag for Review] - Save but mark for later verification

### Decision Point: STAGE 3 STATUS

**EyeMed** âœ… COMPLETE (2026-01-15)
- All 3 checkpoints PASS
- 0 products with `uc_discount`
- Test patients verified (see table above)

**VSP** ðŸ”„ IN PROGRESS - Two-Document Handling
- GPT extraction schema updated for two-document flow
- Tier mappings exist in TypeScript file
- Test documents available (57 files in Test Documents/Insurance Auths/VSP/)
- See **Stage 3.1: VSP Two-Document Authorization** below

**Spectera** â³ NOT YET TESTED
- GPT extraction schema may need updates
- Tier mappings exist in TypeScript file
- Needs test documents

**Action**: EyeMed ready for production use. VSP two-document handling in progress.

---

