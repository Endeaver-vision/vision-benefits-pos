## Stage 8: Analytics

### Functionality Goal
Track business metrics, system performance, and industry KPIs.

### Analytics Categories:

**Sales Metrics:**
- Total revenue by period (day, week, month, year)
- Insurance vs cash pay breakdown
- Average transaction value

**Product Metrics:**
- Top selling products
- Inventory levels

**Quote Metrics:**
- Conversion rate (DRAFT â†’ ACCEPTED â†’ CONVERTED)
- Average quote value
- Time to conversion

**Order Metrics:**
- Percent of orders completed within 8-day timeline
- Percent of orders delayed (outside timeline)
- Average days to completion
- Orders currently behind schedule
- Orders by status (1-8)

**Customer Metrics:**
- New customers by period
- Insurance carrier breakdown (VSP, EyeMed, Spectera)

**Industry KPIs (Capture Rates):**
- Retinal image screening
- OCT screening
- Visual field screening
- Frame capture rate
- Lens capture rate
- Second pair sales
- Neurolens capture
- Annual supply contact lens sales

**Medical Diagnostics:**
- Medical diagnostics testing (general)
- Medical fundus photos
- Medical OCTs (macula and optic nerve)
- Anterior segment photos
- Medical visual fields

### Database Schema:

**AnalyticsSnapshot Table** (daily aggregates):
- `date` - Date of snapshot
- `totalRevenue` - Daily revenue
- `insuranceRevenue` - Insurance portion
- `cashRevenue` - Cash portion
- `transactionCount` - Number of sales
- `newCustomers` - New customers added
- `quotesCreated` - Quotes created
- `quotesConverted` - Quotes converted to orders
- `ordersCreated` - Orders placed
- `ordersCompleted` - Orders delivered
- `ordersOnTime` - Orders within 8 days
- `ordersDelayed` - Orders past 8 days

**ProductAnalytics Table** (aggregated):
- `productId` - Foreign key to product
- `productName`, `productType`
- `unitsSold` - Total units
- `revenue` - Total revenue
- `period` - "daily", "weekly", "monthly", "yearly"

**KPICaptureRate Table** (daily):
- `date` - Date of capture
- `totalExams` - Total exams performed
- `retinalScreeningCount` - Retinal images sold
- `octScreeningCount` - OCT scans sold
- `visualFieldCount` - Visual fields sold
- `framesCaptured` - Frames sold
- `lensesCaptured` - Lenses sold
- `secondPairCount` - Second pairs sold
- `neurolensCount` - Neurolens sold
- `annualSupplyCLCount` - Annual supply CL sold
- `medicalDiagnosticsCount` - Medical diagnostics
- `medicalFundusCount` - Medical fundus photos
- `medicalOCTCount` - Medical OCTs
- `anteriorSegmentCount` - Anterior segment photos
- `medicalVisualFieldCount` - Medical visual fields

### Decision Point: STAGE 8 COMPLETE
**Test 1**: Sales metrics display
- Revenue totals calculate correctly
- Insurance vs cash breakdown accurate

**Test 2**: Order timeline analytics
- Percent on-time vs delayed displays
- Current delayed orders list shows

**Test 3**: Industry KPI capture rates
- Capture rates calculate correctly (sold / total exams)
- Medical diagnostics tracked separately

**Test 4**: Product analytics
- Top products display
- Revenue by product accurate

**Action**: If ALL PASS â†’ System complete. If FAIL â†’ Fix analytics queries.

---

## Build Order Summary

```
STAGE 1: Products & Inventory
    â†“ (verify all products have cash prices)
STAGE 2: Insurance Mapping
    â†“ (verify all products have tier assignments)
STAGE 3: Scanner + Price List Generation
    â†“ (verify extraction + 3 automated checks + human review)
STAGE 4: Patient Profile
    â†“ (verify authorization linked to customer)
STAGE 5: Patient Price List Display
    â†“ (verify price list accessible)
STAGE 6: Quote Generation
    â†“ (verify quote builder pricing)
STAGE 7: Order Tracking
    â†“ (verify order conversion)
STAGE 8: Analytics
    â†“ (verify metrics)
COMPLETE
```

---

## Critical Success Factors

1. **Complete Product Data**: Every product must have cash price and tier assignments for all carriers
2. **100% Data Fidelity**: Scanner must extract AND store ALL copay data
3. **Automated + Human Validation**: 3 automated checkpoints + human visual inspection before approval
4. **Accurate Price Calculation**: Price list must use tier-based pricing when mappings exist
5. **Sequential Validation**: Each stage must pass decision point before proceeding

---

## Validation Workflow (CRITICAL)

**The only validation that matters is what users see in the browser.**

### Three-Layer Validation

```
PDF â†’ Database â†’ API â†’ UI Display
     â†‘            â†‘        â†‘
   Layer 1    Layer 2   Layer 3 (MOST IMPORTANT)
```

Validating only Layer 1 (PDF â†’ DB) will miss bugs where data is stored correctly but displayed incorrectly.

### Validation Commands

**Layer 3: UI Display Validation (USE THIS)**
```bash
npx playwright test e2e/validate-insurance-display.spec.ts --headed
```
- Loads actual browser and checks rendered DOM
- Validates insurance values display correctly (not "Not covered")
- This catches ALL display bugs

**Layer 2: API Response Validation**
```bash
npx tsx scripts/validate-ui-display.ts
```
- Checks what APIs return vs database values
- Faster but doesn't catch UI rendering issues

**Layer 1: PDF Extraction Validation**
```bash
npx tsx scripts/run-vsp-validation.ts
```
- Validates PDF â†’ Database extraction
- Does NOT validate display

### When to Run Validations

| After This Action | Run This Validation |
|-------------------|---------------------|
| Processing insurance documents | UI Display (Layer 3) |
| Changing API routes | Restart server, then UI Display (Layer 3) |
| Extraction code changes | All three layers |
| Before reporting "X customers processed" | UI Display (Layer 3) |

### Key Files

- `/e2e/validate-insurance-display.spec.ts` - Playwright UI tests
- `/scripts/validate-ui-display.ts` - API validation script
- `/src/app/api/customers/[id]/authorization/route.ts` - Authorization API
- `/src/app/api/customers/[id]/insurance-summary/route.ts` - Summary banner API

### Lessons Learned

1. **VSP CL Exam Copay = Contact Lens Fitting** - Same value, different names. The `clExamCopay` DB column displays as "CL Fit" in UI.

2. **Prisma Decimal fields need `Number()` conversion** - Always wrap Decimal values in `Number()` when returning from APIs.

3. **After API changes, restart Next.js server** - Code changes don't take effect until server restarts.

---

