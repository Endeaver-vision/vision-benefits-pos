# Vision POS Build Plan - MASTER INDEX

**Last Updated**: 2026-02-10
**Current Focus**: Stage 3 - Insurance Scanner (BROKEN - needs fixing)

---

## System Overview

Vision POS is a quote flow and point-of-sale system for optical practices. The system follows a **sequential data flow** to generate accurate patient quotes based on insurance benefits and product catalog.

### 8 Components:

1. **Products & Inventory** (Blue) - DATABASE
2. **Insurance Mapping** (Indigo) - FILE (TypeScript mapping file, not database)
3. **Insurance Scanner** (Purple) - Processing + DATABASE (unified authorizations table)
4. **Patient Profile** (Emerald) - DATABASE
5. **Patient Price List** (Teal) - DATABASE
6. **Quote Generation** (Amber) - DATABASE
7. **Order Tracking** (Rose) - DATABASE
8. **Analytics** (Cyan) - DATABASE

---

## Primary Flow (Critical Path)

```
Products → Insurance Mapping → Scanner → Patient Profile → Price List → Quote → Order Tracking → Analytics
```

Each stage must be functional before proceeding to the next.

---

## DOCUMENTATION FILES

Read these files in your terminal AI (Claude Code) as needed:

### Core Stages
- **STAGE_1_PRODUCTS.md** - Product catalog setup and validation
- **STAGE_2_INSURANCE_MAPPING.md** - TypeScript tier mapping file (COMPLETE)
- **STAGE_3_SCANNER_MAIN.md** - Insurance document processing core (CURRENT PROBLEM)
- **STAGE_3_VSP_DETAILS.md** - VSP-specific extraction details and substages
- **STAGE_4_PATIENT_PROFILE.md** - Patient demographics and insurance linkage
- **STAGE_5_PRICE_LIST.md** - Precomputed personalized pricing
- **STAGE_6_QUOTES.md** - Quote generation and PDF output
- **STAGE_7_ORDERS.md** - Order tracking and sales recording
- **STAGE_8_ANALYTICS.md** - Reporting and insights

### Supporting Documentation
- **PRICING_RULES.md** - All carrier-specific pricing rules and formulas
- **SCANNER_TROUBLESHOOTING.md** - Known issues and fixes for Stage 3

---

## CURRENT STATUS

**WORKING:**
- Stage 1: Products & Inventory ✅
- Stage 2: Insurance Mapping ✅

**BROKEN:**
- Stage 3: Insurance Scanner ❌
  - Inaccurate numbers from GPT extraction
  - Occasionally no pricing info extracted
  - Wrong pricing info completely
  - Not recognizing complex copay structures
  - Filling in nonsense data
  - Using fallback 20% discount incorrectly
  - Creating copays for cash-only items

**NOT STARTED:**
- Stages 4-8

---

## QUICK START FOR TERMINAL AI

```bash
# Read this master file first
view MASTER.md

# Then read the stage you're working on
view STAGE_3_SCANNER_MAIN.md  # Core scanner functionality
view STAGE_3_VSP_DETAILS.md   # VSP-specific details if needed

# For pricing issues, read the rules
view PRICING_RULES.md

# For troubleshooting scanner
view SCANNER_TROUBLESHOOTING.md
```

---

**End of Master Index**
