## Stage 7: Insurance Verification Framework âœ… COMPLETE

**Status**: Implementation complete (2026-01-28)
**Purpose**: Systematic testing and validation of insurance extraction and pricing accuracy

### Components Implemented

1. **Database Schema** - Verification tracking tables
   - `verification_runs` - Track each verification run with status and summary
   - `verification_results` - Per-field results (expected vs extracted vs database)
   - `expected_values` - Ground truth values from PDFs

2. **Verification Pipeline** (`scripts/verify-insurance-pipeline.ts`)
   - Loads expected values from JSON files
   - Compares against database authorization data
   - Verifies VSP matrix codes and EyeMed tier pricing
   - Records pass/fail/warning status for each field
   - Generates summary reports

3. **Export Tools** (`scripts/export-verification-results.ts`)
   - CSV export for agent review
   - JSON export for programmatic access
   - HTML dashboard for visual audit

4. **Test Data Structure**
   ```
   /test-documents/
   â”œâ”€â”€ vsp/
   â”‚   â”œâ”€â”€ auth/           # VSP authorization PDFs
   â”‚   â”œâ”€â”€ lens/           # VSP lens enhancement PDFs
   â”‚   â””â”€â”€ expected/       # Expected values JSON files
   â”œâ”€â”€ eyemed/
   â”‚   â”œâ”€â”€ benefits/       # EyeMed benefits PDFs
   â”‚   â””â”€â”€ expected/       # Expected values JSON files
   â””â”€â”€ eops/               # End-of-period statements for final verification
   ```

### Usage

```bash
# Run VSP verification
npx tsx scripts/verify-insurance-pipeline.ts --carrier=VSP --format=json

# Run EyeMed verification
npx tsx scripts/verify-insurance-pipeline.ts --carrier=EyeMed --format=json

# Export results for agent review
npx tsx scripts/export-verification-results.ts --latest --format=csv

# Export HTML dashboard
npx tsx scripts/export-verification-results.ts --latest --format=html
```

### Verification Workflow

1. **Create Expected Values** - Manually extract values from PDFs into JSON files
2. **Run Verification** - Compare expected values against database
3. **Review Results** - Export CSV/HTML for agent verification
4. **Audit** - User spot-checks random samples against source PDFs
5. **EOP Validation** - Final proof using actual insurance company EOPs

### Current Test Coverage

- **VSP**: 5 customers with expected values (Susan McCrae, Tyler Richards, Sarah Rivera, Maritza Kuzian, Tamara Carr)
- **EyeMed**: 5 customers with expected values (Yuenmei Kwan, Thomas Chadwick, Joseph Hernandez, Emilia A'bell, Steven Zhang)

### Last Verification Run Results (2026-01-28)

**VSP**: 209 pass, 0 fail, 33 warnings (86.4% pass rate)
- Warnings are null values for fields not in all PDFs (expected behavior)

**EyeMed**: 15 pass, 0 fail, 0 warnings (100% pass rate)
- All base copays verified correctly

### Decision Point: STAGE 7 COMPLETE

**Test 1**: Verification runs without errors
```bash
npx tsx scripts/verify-insurance-pipeline.ts --carrier=ALL
```
**Result**: Runs complete with summary output

**Test 2**: Export generates valid files
```bash
ls reports/verification-results-*.csv
ls reports/verification-results-*.html
```
**Result**: Files exist and contain verification data

**Test 3**: No critical failures in expected fields
- Base copays (examCopay, materialsCopay, frameAllowance) all pass
- Matrix codes match expected values

---

## Stage 8: EyeMed Pricing Accuracy Fixes âœ… COMPLETE

**Status**: Implementation complete (2026-01-29)
**Purpose**: Fix EyeMed price list generation to correctly apply tier-based copays and discounts

### Issues Identified

1. **Extraction Normalization Missing** - Haiku extraction stored raw field names like `COPAYS_SINGLE_VISION_LENSES` but precompute expected normalized names like `singleVision`
2. **Missing Tier Mapping** - `high_index_174` was not in EYEMED_TIER_TO_COPAY
3. **Wrong Tier Assignment** - Technical Add-On had `eyemed: "all_other_lens_options"` but is VSP-only
4. **Database Tier Codes** - Hi-Index products had NULL tierEyemed values

### Fixes Implemented

1. **haiku-extraction.ts** - Added `buildEyemedNormalizedCopays()` function
   - Maps raw extracted keys to normalized field names
   - Flexible search across COPAYS_, COVERAGE_DETAILS_, and other sections
   - Handles "All Other Lens Options" 20% discount detection
   - Output now includes normalized copays for precompute compatibility

2. **insurance-tier-mappings.ts** - Updated tier mappings
   - Added `high_index_174: "DISCOUNT_20_PERCENT"` to EYEMED_TIER_TO_COPAY
   - Changed Technical Add-On to `eyemed: null` (VSP-only product)
   - Changed Hi-Index 1.72 to `eyemed: "all_other_lens_options"`

3. **Database Updates** - Updated lens_products table
   - Hi-Index 1.74: tierEyemed = "high_index_174"
   - Hi-Index 1.72: tierEyemed = "all_other_lens_options"
   - Technical Add-On: tierEyemed = null

### Pricing Categories (EyeMed)

| Category | Products | Pricing Method |
|----------|----------|----------------|
| `ins_benefit` | Single Vision, Bifocal, Trifocal, Polycarbonate, AR coatings, Transitions | Fixed copay from authorization |
| `ins_discount` | Hi-Index 1.67/1.72/1.74, Prism, Oversize (when covered Rx) | 20% off retail ("All Other Lens Options") |
| `cash_only` | Neurolens, Sequel, Stellest, Varilux I design, Technical Add-On | Full retail price |

### Verification Results (Angela Clayton - EyeMed)

After fixes:
- 12 cash_only products correctly identified
- 23 ins_discount products (20% off retail)
- 11 by_tier products with correct copays ($25 SV, $25 Bifocal, $40 Poly, etc.)

### Customer Selection Persistence Fix

Also fixed patient selection not persisting when navigating away:
- Added localStorage as backup to sessionStorage
- Updated quote-builder/page.tsx, customer-profile.tsx, customer-management.tsx
- Customer selection now survives browser refresh and tab navigation

### Decision Point: STAGE 8 COMPLETE

**Test 1**: EyeMed extraction produces normalized copay fields
```bash
npx tsx scripts/reprocess-angela.ts
# Output shows: singleVision: 25, bifocal: 25, polycarbonate: 40, etc.
```

**Test 2**: Price list shows correct pricing methods
- Visit customer profile > Price List tab
- Hi-Index products show "ins_discount" (not "cash_only")
- Technical Add-On shows "cash_only"

**Test 3**: Customer selection persists across navigation
- Select customer in Quote Builder
- Navigate away and return
- Customer is still selected

---

## Gate Checks (Go/No-Go)

- **Stage 1 Gate**: Zero products with NULL cash prices
- **Stage 2 Gate**: Zero products with NULL tier assignments
- **Stage 3 Gate**: All 3 automated checks PASS + human approval
- **Stage 4 Gate**: Authorization and price list linked to customer
- **Stage 5 Gate**: Price list accessible and displays correct prices
- **Stage 6 Gate**: Quote prices match CustomerPriceList exactly
- **Stage 7 Gate**: Orders auto-create from CONVERTED quotes
- **Stage 8 Gate**: Analytics display correct aggregated data

**Rule**: Do not proceed past a gate until all tests pass.

---

## Simplified Decision Tree

```
Start
  â†“
Products complete? â†’ NO â†’ Fix product data â†’ Test again
  â†“ YES
Insurance mappings complete? â†’ NO â†’ Fix tier assignments â†’ Test again
  â†“ YES
Scanner + Price List validated? â†’ NO â†’ Fix extraction/generation â†’ Test again
  â†“ YES
Patient profile linked? â†’ NO â†’ Fix linkage â†’ Test again
  â†“ YES
Price list accessible? â†’ NO â†’ Fix display â†’ Test again
  â†“ YES
Quotes functional? â†’ NO â†’ Fix quote builder â†’ Test again
  â†“ YES
Orders tracking? â†’ NO â†’ Fix order creation â†’ Test again
  â†“ YES
Analytics working? â†’ NO â†’ Fix queries â†’ Test again
  â†“ YES
LAUNCH READY
```

---

## Pricing Rules Reference (AUTHORITATIVE)

**Created:** 2026-01-29

### Three Pricing Categories

Every product falls into ONE of these categories:

#### 1. Insurance Benefit (`ins_benefit`)
Pricing defined by the member's insurance plan. Includes:
- **Flat copays** - e.g., Single Vision: $25
- **Tiered copays** - e.g., Progressive Tier 3: $110
- **Allowances** - e.g., Frame: $180 allowance, 20% off overage
- **Plan discounts** - e.g., "All Other Lens Options: 20% off retail"
- **Complex formulas** - e.g., Progressive Premium: $25 copay + 80% of (retail - $120 allowance)

**Rule:** If a product is a lens or lens option and NOT explicitly listed in the plan, it falls under "All Other Lens Options" and gets the plan's discount (typically 20% off retail for EyeMed).

#### 2. Provider Contract Discount (`contract_discount`)
Discounts we are contractually obligated to provide when part of a covered order. This is NOT an insurance benefit - it's our agreement with the carrier.

**Products in this category:**
- Oversize Lenses
- Prism

**Rule:** These get 20% off retail ONLY when bundled with a covered pair of glasses. If the patient is paying cash for everything, no contract discount applies.

**Flag:** `requiresCoveredRx: true`

#### 3. Cash Only (`cash_only`)
Products completely outside insurance. Patient pays full retail. No discounts.

**Products in this category:**
- Neurolens SV
- Neurolens Progressive
- Neurolens Premium AR
- Neurolens Blue AR
- Sequel Single Vision
- Sequel PAL
- Varilux I design
- Stellest

**Rule:** These are NEVER covered by insurance. Always full retail price regardless of carrier or plan.

---

### Pricing Methods Reference

| Method | Description | Example |
|--------|-------------|---------|
| `copay` | Flat dollar copay from plan | SV: $25 |
| `copay_plus_allowance` | Copay + percentage of amount over allowance | Progressive Premium: $25 + 80% of (retail - $120) |
| `ins_discount` | Percentage discount defined by insurance plan | All Other: 20% off |
| `allowance` | Dollar allowance, discount on overage | Frame: $180 allowance, 20% off overage |
| `contract_discount` | Provider contract discount (requires covered Rx) | Oversize: 20% off with covered glasses |
| `cash_only` | Full retail, no coverage | Neurolens: $700 |
| `covered` | $0 - fully covered by plan | Exam: $0 copay |

---

### EyeMed Specific Rules

#### "All Other Lens Options"
This is EyeMed's catch-all benefit. ANY lens option not explicitly listed gets this discount (typically 20% off retail).

**Applies to:**
- Materials not listed (Trivex, Hi-Index variants)
- AR coatings not in Standard tier
- Photochromic lenses
- Polarized lenses
- Blue light filters
- Specialty progressives not in tier list
- Edge treatments
- Tints beyond basic
- Any other lens enhancement

**Does NOT apply to:**
- Cash-only products (Neurolens, Sequel, Varilux I design, Stellest)
- Contract discount products when Rx is not covered

#### Progressive Premium Formula
Many EyeMed plans use: `$25 copay + 80% of (retail - $120 allowance)`

```
if (retail <= allowance) {
  patientPays = copay  // Just the copay, nothing extra
} else {
  overage = retail - allowance
  patientPays = copay + (overage * 0.80)
}
```

**Example:** Varilux Comfort Max @ $393.30 retail
- Copay: $25
- Allowance: $120
- Overage: $393.30 - $120 = $273.30
- Patient pays for overage: $273.30 Ã— 0.80 = $218.64
- **Total: $25 + $218.64 = $243.64**

#### Age-Based Pricing
- **Polycarbonate (under 19):** $0 copay
- **Polycarbonate (19 and over):** $40 copay

System must check patient age and apply correct copay.

---

### Implementation Checklist

When building/updating pricing:

- [ ] Check if product is in "Cash Only" list â†’ full retail
- [ ] Check if product is in "Contract Discount" list â†’ 20% off IF covered Rx
- [ ] Otherwise, look up insurance benefit
- [ ] If no specific benefit found, use "All Other Lens Options" discount
- [ ] For complex formulas, implement copay + allowance + discount logic
- [ ] Check patient age for age-based copays

---

## Pricing Example: Angela Clayton (EyeMed)

**Member ID:** 20706244103 | **DOB:** 02/15/1970 (Age 55) | **Network:** Access 101 FF 360

### Benefits from Document

| Category | Benefit |
|----------|---------|
| Exam | $0 copay |
| Frame | $0 copay; 20% off balance over $180 allowance |
| Single Vision / Bifocal / Trifocal | $25 copay |
| Progressive - Standard | $25 copay |
| Progressive - Premium / Tier 4 | $25 copay + 80% of (retail - $120 allowance) |
| AR Coating - Standard | $45 |
| AR Coating - Premium | 20% off retail |
| Polycarbonate (age 19+) | $40 |
| Polycarbonate (under 19) | $0 |
| Scratch / Tint / UV | $15 |
| All Other Lens Options | 20% off retail |

### Calculated Price List

| Product | Retail | Patient Pays | Method |
|---------|--------|--------------|--------|
| **LENSES** |
| Single Vision | $80 | **$25** | copay |
| Essilor Eyezen+ | $129 | **$103** | ins_discount (All Other) |
| Flat Top 28 | $126 | **$25** | copay |
| Varilux Comfort DRx | $254 | **$132** | copay_plus_allowance |
| Varilux Comfort Max | $393 | **$244** | copay_plus_allowance |
| Varilux X Design | $600 | **$409** | copay_plus_allowance |
| Varilux I design | $480 | $480 | cash_only |
| Sequel PAL | $535 | $535 | cash_only |
| Neurolens Progressive | $700 | $700 | cash_only |
| **MATERIALS** |
| CR-39 (Standard) | $0 | **$0** | covered |
| Polycarbonate | $65 | **$40** | copay (age 19+) |
| Trivex | $85 | **$68** | ins_discount (All Other) |
| Hi-Index 1.67 | $125 | **$100** | ins_discount (All Other) |
| Hi-Index 1.74 | $175 | **$140** | ins_discount (All Other) |
| Hi-Index 1.72 | $150 | **$120** | ins_discount (All Other) |
| **AR COATINGS** |
| Crizal Easy Pro | $148 | **$118** | ins_discount (Premium AR) |
| Crizal Rock | $145 | **$116** | ins_discount (Premium AR) |
| Crizal Sapphire HR | $180 | **$144** | ins_discount (Premium AR) |
| Crizal Sunshield UV | $178 | **$15** | copay (UV Treatment) |
| Neurolens AR | $180 | $180 | cash_only |
| **PHOTOCHROMIC** |
| Transitions GEN S | $175 | **$140** | ins_discount (All Other) |
| Transitions XTRActive | $145 | **$116** | ins_discount (All Other) |
| **MOUNT FEES** |
| Full Rim | $0 | **$0** | covered |
| Semi Rimless | $35 | **$28** | ins_discount (All Other) |
| Rimless (drill) | $47 | **$38** | ins_discount (All Other) |
| **ADDONS** |
| UV Protection | $15 | **$15** | copay |
| Solid Tint | $18 | **$15** | copay |
| Essential Blue Series | $30 | **$24** | ins_discount (All Other) |
| Polarized | $156 | **$125** | ins_discount (All Other) |
| Oversize | $30 | **$24** | contract_discount |
| Prism | $8 | **$7** | contract_discount |

---

## Future Phase: Alpha/Beta Testing Infrastructure

### Price Accuracy Monitoring

**Error Tracking System**
Track when calculated prices are incorrect and need manual adjustment:
- Log price overrides with reason codes (extraction error, tier mismatch, formula issue)
- Dashboard showing products with frequent overrides
- Alert when same product fails for multiple customers (indicates tier mapping issue)
- Track correction patterns to improve extraction prompts

**Fallback Price Tracking**
Monitor how often fallback pricing is used:
- Count of products using "all_other_lens_options" 20% discount as fallback
- Count of products with no tier mapping (80% retail fallback)
- Percentage of orders with at least one fallback-priced item
- Flag products that should have tier mappings but don't

### Data Capture System

**Testing Phase Data Collection**
During alpha/beta, capture data to validate and improve the system:
- Log every extraction with raw OCR text + extracted JSON
- Store expected vs actual prices for each order
- Capture user corrections and reason codes
- Track time spent on manual adjustments per order

**EOP Validation**
Compare our calculated prices against actual EOPs (Explanation of Payment):
- Upload EOP documents after insurance processes claims
- Match our price list prices to EOP line items
- Flag discrepancies for investigation
- Build confidence scores for carrier/plan combinations

**Metrics to Track**
- Extraction accuracy rate by carrier
- Price calculation accuracy rate by product category
- Time saved vs manual pricing
- Manual intervention rate per order
- User satisfaction scores

---

**End of Build Plan**
