## Stage 7: Order Tracking

### Functionality Goal
Track orders from quote conversion through patient pickup with 8-day timeline.

### 8 Status States (Timeline):
**Day 0 (Same day as quote):**
1. Invoiced
2. Order placed

**Day 1:**
3. Shipped to vendor

**Days 2-6 (5 days):**
4. Vendor processing

**Day 7:**
5. Vendor shipped

**Day 8 (Combined same day):**
6. Received
7. QC
8. Patient notified

**Total: 8 business days**

### Must Have Features:
- Click to update status
- Edit capability (move back if wrong stage)
- Notes section for each status update
- Vendor specification field
- Timestamp when status changes
- QC checklist (stage 7):
  - Correct frame âœ“
  - Correct vision type (multifocal, SV near, SV distance) âœ“
  - Frame and lenses in good condition âœ“
  - Rx verified by auto lensometer within tolerance âœ“
- Patient notification method (stage 8):
  - Left message
  - Spoke with patient
  - Texted with confirmation
  - Texted without confirmation
- Order views:
  - **Active orders** (not confirmed pickup)
  - **Orders waiting to be picked up** (confirmed notification)
- Timeline tracking:
  - Orders on schedule
  - Orders delayed

### Database Schema:

**Order Table:**
- `orderNumber` - Auto-generated (O-YYYYMMDD-XXXX)
- `quoteId` - Foreign key to Quote
- `customerId` - Patient reference
- `status` - Current status (1-8)
- `vendorName` - Vendor specification
- `createdAt` - Order creation timestamp
- `expectedDeliveryDate` - Day 8 calculated date
- `isDelayed` - Boolean (behind timeline)
- `isPickupConfirmed` - Boolean (patient notification confirmed)
- `totalAmount` - Order total

**OrderItem Table:**
- `orderId` - Foreign key to Order
- `productId`, `productName`, `sku`
- `quantity`, `unitPrice`, `lineTotal`

**OrderStatusHistory Table:**
- `orderId` - Foreign key to Order
- `status` - Status (1-8)
- `statusName` - "Invoiced", "Order placed", etc.
- `timestamp` - When status changed
- `notes` - Optional notes for this status
- `updatedBy` - Staff member

**OrderQC Table:**
- `orderId` - Foreign key to Order (one-to-one)
- `correctFrame` - Boolean
- `correctVisionType` - Boolean
- `visionType` - "Multifocal", "SV Near", "SV Distance"
- `goodCondition` - Boolean
- `rxVerifiedLensometer` - Boolean
- `qcPassedAt` - Timestamp
- `qcBy` - Staff member

**OrderNotification Table:**
- `orderId` - Foreign key to Order (one-to-one)
- `notificationMethod` - "Left message", "Spoke with patient", "Texted with confirmation", "Texted without confirmation"
- `notifiedAt` - Timestamp
- `notifiedBy` - Staff member

### Decision Point: STAGE 7 COMPLETE
**Test 1**: Create order from quote
- Order auto-generates number
- Order items match quote items
- Expected delivery date calculated (8 business days)

**Test 2**: Update order status
- Status changes from 1 â†’ 2 â†’ 3, etc.
- Timestamp recorded in OrderStatusHistory
- Notes save correctly

**Test 3**: QC checklist
- All checkboxes functional
- QC data saves to OrderQC table

**Test 4**: Patient notification
- Notification method saves
- Confirmed = moves to "waiting to be picked up"
- Not confirmed = stays in "active orders"

**Test 5**: Timeline tracking
- Orders on day 9+ flagged as delayed
- Dashboard shows on-time vs delayed

**Action**: If ALL PASS â†’ Proceed to Stage 8. If FAIL â†’ Fix order tracking.

---

