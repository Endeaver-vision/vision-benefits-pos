## Stage 5: Patient Price List (Display & Access) âœ… COMPLETE

**Status**: Complete - implemented in `CustomerPricePlan` component
**Updated**: 2026-01-20 - UI Consolidation for clarity

### Functionality Goal
Provide access to patient-specific pricing for quote building.

### Must Have:
- Price list accessible from customer profile âœ… ("Price List" tab - now FIRST/default tab)
- Prices match generated values from Stage 3 âœ…
- Search/filter functionality âœ… (search + category + carrier filters)
- Manual price override capability (with audit trail) âœ… (override modal with reason)
- Price list history (view old/inactive lists) âœ…
- Export to CSV âœ… (implemented 2026-01-27)

### Implementation: CustomerPricePlan Component
**Location**: `src/components/customers/customer-price-plan.tsx`
**API**: `src/app/api/customers/[id]/price-plan/route.ts`

### Export Functionality (Added 2026-01-27)
**Feature**: Export CSV button next to "Regenerate Prices"
**Location**: `src/components/customers/customer-insurance-pricing.tsx`
**Output**: CSV file with columns: Product, Category, SKU, Retail Price, Customer Price, Savings, Tier, Carrier
**Filename**: `price-list-{customername}-{date}.csv`

### Unified Price List UI (Updated 2026-01-27)
**Change**: Merged insurance benefits and products into ONE card (not separate cards)
**Layout**: Insurance header â†’ Benefits row â†’ Products/History tabs (all in same card)
**Result**: Benefits section flows directly into product list, no visual separation

### UI Layout (Consolidated - 2026-01-20):

**Tab Order** (Price List is default):
1. **Price List** (default) - Main pricing view
2. Benefits Detail - Full copay breakdown
3. Price List History - Old/inactive lists

**Price List Layout**:
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ ðŸ¥ EyeMed - Humana VCP | Member: 22868382200                        â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ BENEFITS SUMMARY ROW:                                               â”‚
â”‚ Exam: $10 | CL Fit: $40 | Materials: $10 | Frame: $250-375 | CL: $150 â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ [Search products...]                            [Filter: All â–¼]     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ PRODUCTS (not "Everyday" - just "Products")                         â”‚
â”‚ â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”â”‚
â”‚ â”‚ Product         â”‚ Retail  â”‚ You Pay           â”‚ Savings         â”‚â”‚
â”‚ â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤â”‚
â”‚ â”‚ Single Vision   â”‚ $45     â”‚ $10 copay         â”‚ $35             â”‚â”‚
â”‚ â”‚ Prog Tier 1     â”‚ $195    â”‚ $80 copay         â”‚ $115            â”‚â”‚
â”‚ â”‚ Polycarbonate   â”‚ $85     â”‚ $25 copay         â”‚ $60             â”‚â”‚
â”‚ â”‚ Hi-Index 1.67   â”‚ $125    â”‚ 20% off ($100)    â”‚ $25             â”‚â”‚
â”‚ â”‚ Trivex          â”‚ $85     â”‚ 20% off ($68)     â”‚ $17             â”‚â”‚
â”‚ â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜â”‚
â”‚                                                                     â”‚
â”‚ CONTACT LENSES (special display for allowance-based pricing)        â”‚
â”‚ â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”â”‚
â”‚ â”‚ $150 allowance, then patient pays 100% of overage               â”‚â”‚
â”‚ â”‚ CL Fitting: 85% of amount over allowance (15% discount)         â”‚â”‚
â”‚ â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

**Key Display Rules**:
1. **"You Pay" column shows context**, not just numbers:
   - `$10 copay` - explicit copay from tier
   - `20% off ($80)` - when DISCOUNT_20 applies (show calculated amount)
   - `$150 allowance + overage` - for allowance-based items like contacts
   - Never show "N/A" for extracted values - show actual benefit text

2. **Benefits Summary Row** (compact, always visible):
   - Exam Copay
   - CL Fit Copay (next to exam - both are service copays)
   - Materials Copay
   - Frame Allowance (show range if min/max)
   - Contact Lens Allowance

3. **Price List History** (new tab):
   - Shows all price lists for customer (active + inactive)
   - Date created, carrier, status, product count
   - Can view/compare old lists
   - Old lists auto-deactivated when new auth scanned (same carrier)

**Special Pricing Values** (from insurance auth):
- `"DISCOUNT_20"` â†’ Display as "20% off" with calculated price
- `"100% of amount over remaining balance"` â†’ Patient pays full overage
- `"85% of amount over remaining balance"` â†’ Patient pays 85% of overage (15% discount)
- `null` â†’ Show as "At retail" (not "N/A")

### Decision Point: STAGE 5 COMPLETE âœ…
**Test 1**: View price list in customer profile â†’ "Price List" tab (first tab) âœ…
**Test 2**: Search for products by name âœ…
**Test 3**: Generate price plan from authorization âœ…
**Test 4**: Override individual product price âœ…
**Test 5**: View price list history (old/inactive lists) âœ…
**Test 6**: Benefits summary row displays correctly âœ…

---

## Stage 5.5: Insurance Verification Gate (NEW)

**Status**: IN PROGRESS (2026-01-28)
**Priority**: HIGH - Required before quote building

### Functionality Goal

Create a verification gate in the Quote Builder that displays insurance benefits, verifies data freshness, and provides clear paths forward (proceed to quote, re-scan, or self-pay).

### Why This Gate?

1. **EyeMed**: Simple product price list mapped from authorization
2. **VSP**: Matrix-based pricing mapped from two-page authorizations
3. **Both require**: Clear display of benefits before quoting to ensure accurate pricing

### Insurance Verification Gate Requirements

**Display (from Patient Profile - READ ONLY):**
- Carrier (VSP, EyeMed, Spectera)
- Plan Name
- Exam Copay
- Materials Copay
- Frame Allowance (show range if Featured/Non-Featured)
- Contact Lens Allowance
- CL Fit Copay (Contact Lens Fitting copay)
- Last Verified timestamp

**Staleness Check:**
- **48-hour threshold**: If authorization verified > 48 hours ago, show warning
- Warning message: "Insurance last verified X days ago. Re-scan recommended."
- Warning does NOT block quote - user can proceed anyway

**Actions:**
1. **[Proceed to Quote]** - Continue with current insurance benefits
2. **[Go to Scanner]** - Redirect to `/scanner` page to re-scan documents
3. **[Self-Pay]** - Always available, bypasses insurance entirely

### Data Flow (CRITICAL)

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ PATIENT PROFILE (Source of Truth)                                   â”‚
â”‚ â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ â”‚
â”‚ â€¢ insurance_authorizations table                                    â”‚
â”‚ â€¢ patient_price_lists table                                         â”‚
â”‚ â€¢ Authorization copays JSON                                         â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                                â”‚
                                â”‚ READ ONLY (no regeneration!)
                                â–¼
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ INSURANCE VERIFICATION GATE (Quote Builder Entry Point)            â”‚
â”‚ â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ â”‚
â”‚ â€¢ Displays benefits from authorization                              â”‚
â”‚ â€¢ Checks staleness (48-hour warning)                               â”‚
â”‚ â€¢ Provides action buttons                                          â”‚
â”‚                                                                     â”‚
â”‚ â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚ â”‚ ðŸ¥ VSP - Choice Plan                    Last Verified: 2 days ago â”‚
â”‚ â”‚ â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€  â”‚
â”‚ â”‚ âš ï¸ Insurance benefits may be outdated. Re-scan recommended.      â”‚
â”‚ â”‚                                                                   â”‚
â”‚ â”‚ Exam: $10 | Materials: $25 | Frame: $200 | CL: $150 | CL Fit: $40â”‚
â”‚ â”‚                                                                   â”‚
â”‚ â”‚ [Proceed to Quote]  [Go to Scanner]  [Self-Pay]                  â”‚
â”‚ â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                                â”‚
                â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
                â–¼               â–¼               â–¼
         [Quote Builder]   [/scanner]     [Quote Builder]
         (with insurance)  (re-scan)      (self-pay mode)
```

### Implementation Plan

**Component Location**: `src/components/quote-builder/insurance-verification-gate.tsx`

**API Data Source**:
- `/api/customers/[id]/authorization` - Get authorization details
- `/api/customers/[id]/insurance-summary` - Get copay summary

**No New APIs**: Uses existing patient profile APIs (read-only)

### UI Specification

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ SELECT INSURANCE                                                    â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                                     â”‚
â”‚ â— VSP - Choice Plan                                                â”‚
â”‚   Member: 123456789 | Group: 00012345                              â”‚
â”‚   Last Verified: Jan 26, 2026 at 3:45 PM                           â”‚
â”‚                                                                     â”‚
â”‚   â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”â”‚
â”‚   â”‚ âš ï¸ Insurance verified 2 days ago. Re-scan for latest benefits.â”‚â”‚
â”‚   â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜â”‚
â”‚                                                                     â”‚
â”‚   BENEFITS SUMMARY:                                                 â”‚
â”‚   â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”           â”‚
â”‚   â”‚ Exam    â”‚ Materials  â”‚ Frame   â”‚ CL      â”‚ CL Fit â”‚           â”‚
â”‚   â”‚ $10     â”‚ $25        â”‚ $200    â”‚ $150    â”‚ $40    â”‚           â”‚
â”‚   â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”˜           â”‚
â”‚                                                                     â”‚
â”‚   [Proceed with VSP]    [Re-scan Documents]                        â”‚
â”‚                                                                     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ â—‹ EyeMed (no active authorization)                                 â”‚
â”‚   [Scan Documents]                                                  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ â—‹ Self-Pay (No Insurance)                                          â”‚
â”‚   Patient pays retail prices                                        â”‚
â”‚   [Continue as Self-Pay]                                           â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

### Staleness Logic

```typescript
const STALE_THRESHOLD_HOURS = 48;

function isAuthorizationStale(authorization: { updatedAt: Date }): boolean {
  const hoursSinceUpdate = (Date.now() - authorization.updatedAt.getTime()) / (1000 * 60 * 60);
  return hoursSinceUpdate > STALE_THRESHOLD_HOURS;
}
```

### Decision Point: STAGE 5.5 COMPLETE

**Test 1**: Insurance gate displays benefits from patient profile
```
Navigate to Quote Builder â†’ Select customer with VSP authorization
```
**Result**: Benefits summary shows Exam, Materials, Frame, CL, CL Fit copays

**Test 2**: Staleness warning appears for old authorizations
```
Navigate to Quote Builder â†’ Select customer with authorization > 48 hours old
```
**Result**: Warning banner appears: "Insurance verified X days ago..."

**Test 3**: Scanner redirect works
```
Click [Go to Scanner] or [Re-scan Documents]
```
**Result**: Navigates to /scanner page with customer pre-selected

**Test 4**: Self-pay bypasses insurance
```
Select "Self-Pay" option â†’ Proceed to quote
```
**Result**: Quote builder loads in self-pay mode (retail prices)

**Test 5**: Data is read-only (no regeneration)
```
Verify no API calls to regenerate price lists when entering gate
```
**Result**: Only GET requests to authorization/summary APIs

**Action**: If ALL PASS â†’ Gate complete, proceed with quote building

---

### Insurance Summary Component (Updated 2026-01-27)

**Location**: `src/components/quote-builder/insurance-summary.tsx`

**UI Improvements**:
- Header: "Insurance Copays" with plan name inline (unified appearance)
- Tier details toggle: "Lens & Enhancement Copays" with item count
- Tier copays flow naturally from base copays (not visually separate sections)
- Consistent emerald color for copay values

**Design Principle**: Benefits and copays appear as ONE unified section, not separate components.

---

