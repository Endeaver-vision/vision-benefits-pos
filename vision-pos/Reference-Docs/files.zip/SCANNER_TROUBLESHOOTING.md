# Insurance Scanner Troubleshooting Guide

**Last Updated**: 2026-02-10
**Status**: Stage 3 is BROKEN - multiple extraction and pricing issues

---

## CURRENT PROBLEMS

### 1. Inaccurate Numbers
- GPT extracts wrong copay amounts from PDFs
- Numbers sometimes off by 10-20%
- Decimal places incorrect

### 2. Missing Pricing Info
- Occasionally extracts no copay data at all
- Returns empty JSON fields for benefits
- Fails to find obvious copay values in document

### 3. Wrong Pricing Info Completely
- Extracts copays from wrong sections of document
- Mixes up carrier-specific fields
- Confuses progressive tiers with single vision

### 4. Cannot Handle Complex Copays
- Fails on structured copays like "$25 + 80% of (retail - $120)"
- Doesn't recognize allowance-based pricing
- Cannot parse "DISCOUNT_XX" format

### 5. Nonsense Data Insertion
- Fills in random numbers when uncertain
- Creates copay values for uncovered products
- Invents tier mappings that don't exist

### 6. Fallback Abuse
- Defaults to 20% off retail for everything
- Uses "All Other Lens Options" incorrectly
- Never flags extraction failures - just guesses

### 7. Cash-Only Product Errors
- Creates insurance copays for Neurolens products
- Doesn't respect cash_only tier mapping
- Applies discounts to products that should be full retail

---

## ROOT CAUSES

### GPT Prompt Issues
- Extraction prompt may be too vague
- Not enough examples of complex pricing structures
- Missing validation logic in prompt

### Schema Mismatch
- GPT output format doesn't match database schema
- Missing required fields in extraction
- JSON structure inconsistent between carriers

### No Validation
- No checks after extraction before database insert
- No comparison against expected values
- No confidence scoring for extracted data

### Tier Mapping Disconnect
- Extraction doesn't know about PRODUCT_TIERS mappings
- Can't validate if extracted tier codes are valid
- No feedback loop to TypeScript mapping file

---

## DIAGNOSTIC APPROACH

### Step 1: Test with Known Good Documents
Use Angela Clayton (EyeMed) document as baseline:
- Member ID: 20706244103
- Expected: $25 progressive copay, $40 polycarbonate, $15 UV
- Run extraction and compare results field-by-field

### Step 2: Validate Against Schema
Check extracted JSON structure:
```typescript
interface ExtractedAuth {
  carrier: "VSP" | "EyeMed" | "Spectera"
  memberID: string
  effectiveDate: string
  copays: {
    examCopay?: number
    singleVision?: number
    progressiveTier3?: number | string  // Can be number OR "DISCOUNT_XX"
    arTier2?: number | string
    polycarbonate?: number
    allOtherLensOptions?: string  // Usually "DISCOUNT_20"
    // ... more fields
  }
}
```

### Step 3: Test Pricing Calculation
After extraction, verify pricing engine:
1. Load extracted auth into database
2. Run precompute service
3. Check Patient_Price_List table
4. Compare against PRICING_RULES.md expected values

---

## POTENTIAL FIXES

### Fix 1: Stricter GPT Prompt
- Add explicit field definitions with examples
- Include validation rules in prompt
- Require confidence scores for each field

### Fix 2: Multi-Stage Extraction
1. Extract raw text with OCR
2. GPT identifies document structure
3. GPT extracts values with context
4. Validation layer checks output

### Fix 3: Add Validation Layer
Before database insert:
```typescript
function validateExtraction(auth: ExtractedAuth) {
  // Check all copays are numbers or valid discount strings
  // Verify tier codes exist in TIER_TO_COPAY mappings
  // Flag missing critical fields
  // Return confidence score
}
```

### Fix 4: Hybrid Approach
- Use GPT for flexible extraction
- Use regex/pattern matching for known formats
- Cross-validate results between methods

### Fix 5: Expected Values Database
Create test suite:
- Store expected values for known documents
- Run extraction and compare
- Track accuracy over time
- Identify patterns in failures

---

## TESTING CHECKLIST

Before deploying extraction fixes:

- [ ] Test Angela Clayton (EyeMed) document
- [ ] Test VSP two-document authorization
- [ ] Test Spectera document
- [ ] Test document with complex copay formulas
- [ ] Test document with missing fields
- [ ] Test document with "DISCOUNT_XX" strings
- [ ] Verify cash-only products get null tiers
- [ ] Verify price list generation after extraction
- [ ] Check logs for fallback usage
- [ ] Confirm zero `uc_discount` pricing methods

---

## NEXT STEPS

1. **Read STAGE_3_SCANNER.md** for full technical details
2. **Read PRICING_RULES.md** for authoritative pricing logic
3. **Choose a fix approach** from options above
4. **Implement validation layer** as minimum first step
5. **Test with known documents** before touching production

---

**End of Troubleshooting Guide**
