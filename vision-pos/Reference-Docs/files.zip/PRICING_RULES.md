## Pricing Rules Reference (AUTHORITATIVE)

**Created:** 2026-01-29

### Three Pricing Categories

Every product falls into ONE of these categories:

#### 1. Insurance Benefit (`ins_benefit`)
Pricing defined by the member's insurance plan. Includes:
- **Flat copays** - e.g., Single Vision: $25
- **Tiered copays** - e.g., Progressive Tier 3: $110
- **Allowances** - e.g., Frame: $180 allowance, 20% off overage
- **Plan discounts** - e.g., "All Other Lens Options: 20% off retail"
- **Complex formulas** - e.g., Progressive Premium: $25 copay + 80% of (retail - $120 allowance)

**Rule:** If a product is a lens or lens option and NOT explicitly listed in the plan, it falls under "All Other Lens Options" and gets the plan's discount (typically 20% off retail for EyeMed).

#### 2. Provider Contract Discount (`contract_discount`)
Discounts we are contractually obligated to provide when part of a covered order. This is NOT an insurance benefit - it's our agreement with the carrier.

**Products in this category:**
- Oversize Lenses
- Prism

**Rule:** These get 20% off retail ONLY when bundled with a covered pair of glasses. If the patient is paying cash for everything, no contract discount applies.

**Flag:** `requiresCoveredRx: true`

#### 3. Cash Only (`cash_only`)
Products completely outside insurance. Patient pays full retail. No discounts.

**Products in this category:**
- Neurolens SV
- Neurolens Progressive
- Neurolens Premium AR
- Neurolens Blue AR
- Sequel Single Vision
- Sequel PAL
- Varilux I design
- Stellest

**Rule:** These are NEVER covered by insurance. Always full retail price regardless of carrier or plan.

---

### Pricing Methods Reference

| Method | Description | Example |
|--------|-------------|---------|
| `copay` | Flat dollar copay from plan | SV: $25 |
| `copay_plus_allowance` | Copay + percentage of amount over allowance | Progressive Premium: $25 + 80% of (retail - $120) |
| `ins_discount` | Percentage discount defined by insurance plan | All Other: 20% off |
| `allowance` | Dollar allowance, discount on overage | Frame: $180 allowance, 20% off overage |
| `contract_discount` | Provider contract discount (requires covered Rx) | Oversize: 20% off with covered glasses |
| `cash_only` | Full retail, no coverage | Neurolens: $700 |
| `covered` | $0 - fully covered by plan | Exam: $0 copay |

---

### EyeMed Specific Rules

#### "All Other Lens Options"
This is EyeMed's catch-all benefit. ANY lens option not explicitly listed gets this discount (typically 20% off retail).

**Applies to:**
- Materials not listed (Trivex, Hi-Index variants)
- AR coatings not in Standard tier
- Photochromic lenses
- Polarized lenses
- Blue light filters
- Specialty progressives not in tier list
- Edge treatments
- Tints beyond basic
- Any other lens enhancement

**Does NOT apply to:**
- Cash-only products (Neurolens, Sequel, Varilux I design, Stellest)
- Contract discount products when Rx is not covered

#### Progressive Premium Formula
Many EyeMed plans use: `$25 copay + 80% of (retail - $120 allowance)`

```
if (retail <= allowance) {
  patientPays = copay  // Just the copay, nothing extra
} else {
  overage = retail - allowance
  patientPays = copay + (overage * 0.80)
}
```

**Example:** Varilux Comfort Max @ $393.30 retail
- Copay: $25
- Allowance: $120
- Overage: $393.30 - $120 = $273.30
- Patient pays for overage: $273.30 Ã— 0.80 = $218.64
- **Total: $25 + $218.64 = $243.64**

#### Age-Based Pricing
- **Polycarbonate (under 19):** $0 copay
- **Polycarbonate (19 and over):** $40 copay

System must check patient age and apply correct copay.

---

### Implementation Checklist

When building/updating pricing:

- [ ] Check if product is in "Cash Only" list â†’ full retail
- [ ] Check if product is in "Contract Discount" list â†’ 20% off IF covered Rx
- [ ] Otherwise, look up insurance benefit
- [ ] If no specific benefit found, use "All Other Lens Options" discount
- [ ] For complex formulas, implement copay + allowance + discount logic
- [ ] Check patient age for age-based copays

---

