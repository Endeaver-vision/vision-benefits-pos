## Stage 1: Products & Inventory

### Functionality Goal
Complete product catalog with cash prices for all products.

### Product Categories (7 Tables):
1. **LensProduct** - Progressive, Single Vision, Bifocals, AR Coatings, Enhancements
2. **LensMaterial** - Polycarbonate, Trivex, High Index (always separate from lens)
3. **Frame** - All frame inventory with stock tracking
4. **ContactLens** - With annualSupplyThreshold field
5. **DryEyeProduct** - Drops, masks, wipes, devices
6. **Nutraceutical** - Vitamins, supplements
7. **Service** - Exams, fittings, adjustments

### Must Have (ALL Products):
- SKU (unique)
- Name
- Brand
- Cash Price (never NULL, never $0)
- Status (Active/Inactive)
- Aliases (JSON array for search)

### UI Verification: /admin/products
**Route**: `/admin/products` or `/products`
**Purpose**: Visual verification of product catalog completeness

**Display Requirements**:
- Total product count by category
- Products missing required fields (highlighted in red)
- Cash price validation (show any $0 or NULL)
- Active/Inactive status filter
- Search and filter by category

### Decision Point: STAGE 1 COMPLETE
**Test**: Query each product table for missing required fields
```sql
SELECT COUNT(*) FROM LensProduct WHERE cashPrice IS NULL OR sku IS NULL OR name IS NULL;
SELECT COUNT(*) FROM LensMaterial WHERE cashPrice IS NULL OR sku IS NULL OR name IS NULL;
SELECT COUNT(*) FROM Frame WHERE cashPrice IS NULL OR sku IS NULL OR name IS NULL;
SELECT COUNT(*) FROM ContactLens WHERE cashPrice IS NULL OR sku IS NULL OR annualSupplyThreshold IS NULL;
SELECT COUNT(*) FROM DryEyeProduct WHERE cashPrice IS NULL OR sku IS NULL OR name IS NULL;
SELECT COUNT(*) FROM Nutraceutical WHERE cashPrice IS NULL OR sku IS NULL OR name IS NULL;
SELECT COUNT(*) FROM Service WHERE cashPrice IS NULL OR sku IS NULL OR name IS NULL;
```
**Result**: All queries return 0
**UI Check**: Navigate to /admin/products â†’ All categories show green checkmarks
**Action**: If PASS â†’ Proceed to Stage 2. If FAIL â†’ Fix product data.

---

