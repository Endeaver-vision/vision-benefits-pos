## Stage 6: Quote Generation (THE GOSPEL)

### Functionality Goal
Build accurate quotes following service workflow with proper insurance coverage rules. **This is where everything comes together.**

---

### Quote Builder Layers (Sequential):

#### **Layer 1: Exam (REQUIRED FIRST)**

**Routine Vision Exam** (INSURANCE COVERED)
- Comprehensive eye exam
- **Includes refraction** (not charged separately)
- Price from CustomerPriceList (exam copay)
- Example: EyeMed exam copay = $10

**Screening Services** (CASH PAY - Optional)
- Retinal imaging, OCT scan, Visual field test
- Price = retail cash (no insurance)
- Patient can opt in/out

**EXAM REVIEW CHECKPOINT** - Patient must approve exam costs before proceeding to products
- Display exam quote summary
- Show covered vs. cash pay breakdown
- Calculate exam total
- Actions: [Go Back & Edit] [Save Exam Quote] [Proceed to Products]
- Database save: status = EXAM_ONLY

---

#### **Layer 2-5: Product Selection** (After Exam Approval)

**Layer 2: Routine Services** (COVERED)
- Standard adjustments, basic lens cleaning
- Price from CustomerPriceList (may be $0)

**Layer 3: Contact Lens Fitting** (COVERED if applicable)
- Separate from exam copay
- Price from CustomerPriceList (CL fitting copay)
- Only if patient selecting contacts

**Layer 4a: Eyeglasses** (COVERED with allowance)
- Lenses (Progressive/SV/Bifocal)
- Material (Polycarbonate, Trivex, High Index)
- AR Coating
- Enhancements (Photochromic, Polarized, Tint)
- Frame (allowance applied, patient pays overage)
- All prices from CustomerPriceList

**Layer 4b: Contact Lenses** (COVERED - Alternative to eyeglasses)
- Annual supply selection
- Calculate boxes needed
- Price from CustomerPriceList
- **IMPORTANT**: Materials benefit exclusivity - patient chooses eyeglasses OR contacts (not both with insurance)

**Layer 5: Add-on Services** (CASH PAY)
- Second pair, warranties, specialty services
- Price = retail cash (no insurance)

---

### Database Structure:

**Quote Table** (Header)
- `quoteNumber` - Auto-generated (Q-YYYYMMDD-XXXX)
- `customerId` - Patient reference
- `status` - EXAM_ONLY, DRAFT, SENT, ACCEPTED, CONVERTED, EXPIRED
- `quoteType` - EXAM_ONLY, EYEWEAR, CONTACTS, FULL_SERVICE
- `subtotalInsurance` - Insurance-covered items
- `subtotalCashPay` - Cash-pay items
- `totalAmount` - Final total
- `createdAt`, `updatedAt` - Timestamps (auto-save updates)
- `authorizationId` - Insurance reference

**QuoteItem Table** (Line Items)
- `quoteId` - Foreign key to Quote
- `productId`, `productType`, `productName`, `sku`
- `quantity`, `unitPrice`, `lineTotal`
- `isCoveredByInsurance` - true/false
- `tier` - "Progressive Tier 2", "Standard AR", null if cash
- `pricingRule` - "Tier-Based", "80% U&C", "Cash Pay Only"
- `retailPrice`, `savings` - For insurance comparison
- `quoteSection` - EXAM, EYEWEAR, CONTACTS, ADDON_SERVICES
- `sortOrder` - Display order

---

### Auto-Save Logic:

**Saves automatically:**
1. After exam approval â†’ status = EXAM_ONLY
2. After adding each product â†’ updates Quote totals
3. Every 30 seconds (debounced)
4. When navigating between layers
5. Before closing quote builder

**Each save:**
- Adds/updates QuoteItem
- Recalculates Quote totals (insurance + cash subtotals)
- Updates `updatedAt` timestamp

---

### Critical Pricing Rules (THE GOSPEL):

**RULE #1**: Covered services use CustomerPriceList, cash services use retail price
```typescript
if (service.isCoveredByInsurance) {
  price = customerPriceList.find(p => p.productId === service.id)?.finalPrice
} else {
  price = service.retailPrice // Cash pay
}
```

**RULE #2**: Refraction is INCLUDED in routine exam (never charge separately)

**RULE #3**: Materials benefit is exclusive (eyeglasses OR contacts, not both)

**RULE #4**: 80% fallback is VALID when:
- Product has no tier mapping (`eyemedTier = NULL`)
- Product is "Not Covered"
- Pricing rule is "80% U&C"

**RULE #5**: Frame allowance must be applied correctly
```
Frame retail: $250
Frame allowance: $150
Patient pays: $100 (overage as separate line item)
```

**RULE #6**: All prices from CustomerPriceList must match exactly (no recalculation)

---

### Quote Display Format:

```
QUOTE #Q-20260113-0042
Patient: John Smith | EyeMed Select Plus | Member: ABC123456

=== COVERED BY INSURANCE ===
Routine Vision Exam (includes refraction)        $10.00
Varilux X-Series Progressive                    $115.00
Crizal Sapphire AR Coating                       $85.00
Polycarbonate Material                           $40.00
Transitions Photochromic                         $75.00
Frame: Ray-Ban RB5154                           $250.00
  Frame Allowance                              -$150.00
  Frame Overage                                 $100.00
                                   Insurance:   $425.00

=== NOT COVERED - CASH PAY ===
Optomap Retinal Imaging                          $39.00
OCT Scan                                         $75.00
                                    Cash Pay:   $114.00

Subtotal:                                       $539.00
Tax (7%):                                        $37.73
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
TOTAL:                                          $576.73

Retail Value (no insurance): $1,420.00
Your Savings: $843.27 (59%)
```

---

### Decision Point: STAGE 6 COMPLETE

**Test 1**: Exam checkpoint works
```
1. Select exam + screening services
2. Review exam quote (approval screen displays)
3. Click "Proceed to Products"
4. Query database
```
```sql
SELECT status, subtotal FROM Quote WHERE id = [quote_id];
```
**Result**: status = EXAM_ONLY â†’ changes to DRAFT when products added

**Test 2**: Auto-save works
```
1. Add Varilux lens
2. Wait 2 seconds
3. Query QuoteItem count
```
**Result**: Item saved immediately, Quote totals recalculated

**Test 3**: Covered vs. cash pricing correct
```sql
SELECT
  qi.productName,
  qi.unitPrice,
  CASE WHEN qi.isCoveredByInsurance THEN 'Insurance' ELSE 'Cash' END as source
FROM QuoteItem qi
WHERE qi.quoteId = [test_quote_id];
```
**Result**: Exam/lenses/frame show "Insurance", screening shows "Cash"

**Test 4**: Prices match CustomerPriceList exactly
```sql
SELECT
  qi.productName,
  qi.unitPrice as quote_price,
  cpl.finalPrice as price_list_price,
  CASE WHEN qi.unitPrice = cpl.finalPrice THEN 'âœ…' ELSE 'âŒ' END as match
FROM QuoteItem qi
JOIN CustomerPriceList cpl ON cpl.productId = qi.productId
WHERE qi.quoteId = [test_quote_id] AND qi.isCoveredByInsurance = true;
```
**Result**: ALL rows show âœ… (perfect match)

**Test 5**: Materials benefit exclusivity enforced
```
Try to add both eyeglasses AND contacts with insurance
```
**Result**: System prompts "Materials benefit already used. Contacts will be cash pay. Continue?"

**Test 6**: Quote totals calculate correctly
```
Manual calculation:
  Exam: $10
  Lenses/coatings: $315
  Frame overage: $100
  Screening: $114
  Tax (7%): $37.73
  Total: $576.73
```
**Result**: Displayed total matches manual calculation exactly

---

**GOSPEL CHECK** (ALL must pass):
- âœ… Exam checkpoint exists (patient approves before products)
- âœ… All insurance prices from CustomerPriceList (not calculated)
- âœ… Cash pay services use retail price
- âœ… Auto-save works (quote persists)
- âœ… Materials benefit exclusivity enforced
- âœ… Frame allowance applied correctly
- âœ… Totals accurate

**Action**:
- If ALL TESTS PASS + GOSPEL CHECK âœ… â†’ Proceed to Stage 7
- If ANY FAIL â†’ **STOP. Fix quote builder. This is the gospel - must be perfect.**

---

